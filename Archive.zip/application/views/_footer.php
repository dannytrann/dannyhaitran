
<!-- first section - Home -->
<div class="row-fluid">
    <div class="span4 offset4">
        <div class="text-center">
            Copyright &copy; 2014,  <a href="mailto:dannyhaitran@outlook.com">Danny Hai Tran</a>.
        </div>
    </div>
</div>
    <!-- /first section -->
