<!-- first section - Home -->
<div class="container-fluid">
    <div class="row col-md-8 col-xs-10 col-xs-offset-1 col-md-offset-2">
        <div class="text-center cover-absolute">
            <p id="dannyhaitran">DANNY HAI TRAN</p>
            <h5>DEVELOPER ATHLETE ENTREPRENEUR</h5>
        </div>
    </div>
    <div class="col-xs-4 col-sm-2 col-md-2 col-xs-offset-4 col-sm-offset-5 col-md-offset-5" id="viewProjects-div">
        <a href="#content" id="viewProjects" class="btn">VIEW PROJECTS</a>
    </div>  
</div>



<!-- /first section -->
